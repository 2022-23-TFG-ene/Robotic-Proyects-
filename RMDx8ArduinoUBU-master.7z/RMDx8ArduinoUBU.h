#ifndef RMDx8ArduinoUBU_h
#define RMDx8ArduinoUBU_h

#include "Arduino.h"
#include <mcp_can.h>

class RMDx8ArduinoUBU {
public:
    unsigned char len;
    unsigned char tmp_buf[8], cmd_buf[8], reply_buf[8], pos_buf[8];
    int8_t temperature;
    uint8_t anglePidKp, anglePidKi, speedPidKp, speedPidKi, iqPidKp, iqPidKi, error_state, command;
    int16_t iq, speed, iA, iB, iC, angleControlST;
    uint16_t MOTOR_ADDRESS, encoder, encoderRaw, encoderOffset, voltage, circleAngle;
    int32_t Accel, motorAngle, angleControlMT;

    RMDx8ArduinoUBU(MCP_CAN &CAN, const uint16_t motor_addr); // Maneja el controlador si tiene el mismo nombre que la clase

    // Commands
    void canSetup();
    void readPID();
    void writePID(uint8_t anglePidKp, uint8_t anglePidKi, uint8_t speedPidKp, uint8_t speedPidKi, uint8_t iqPidKp, uint8_t iqPidKi); // Write PID to RAM parameter command (one frame)
    void writePIDROM(uint8_t anglePidKp, uint8_t anglePidKi, uint8_t speedPidKp, uint8_t speedPidKi, uint8_t iqPidKp, uint8_t iqPidKi); // Write PID to ROM parameter command (one frame)
    void readAccel(); // Read acceleration data command (one frame)
    void writeAccel(uint32_t Accel); // Write acceleration data command (one frame)
    void readEncoder(); // The host sends the command to read the current position of the encoder
    void writeEncoderOffset(uint16_t encoderOffset);
    void writePositionROMMotorZero(); // Write current position to ROM as motor zero position command(one frame)
    void readMotorAngle(); // Read multi turns angle command
    void readSingleCircleAngle(); // The host sends command to read the single circle angle of the motor.
    void clearState(); // Turn off motor, while clearing the motor operating status and previously received control commands
    void stopMotor(); // Stop motor, but do not clear the motor operating state and previously received control commands
    void resumeStopMotor(); // Resume motor operation from motor stop command (Recovery control mode before stop motor)
    void readStatus1(); // This command reads the motor's error status and voltage, temperature and other information.
    void clearErrorFlag(); // This command clears the error status of the current motor.
    void readStatus2(); // This command reads motor temperature, voltage, speed, encoder position
    void readStatus3(); // This command reads the phase current status data of the motor.
    void writeCurrent(int16_t iqControl);
    void writeSpeed(int32_t speedControl); 
    void writePosition3(int32_t angleControlMT);
    void writePosition4(int32_t angleControlMT, uint16_t maxSpeed);
    void writePosition5(uint16_t angleControlST, uint8_t spinDirection);
    void writePosition6(uint16_t angleControlST, uint16_t maxSpeed, uint8_t spinDirection);

    // General function
    void serialWriteTerminator();

private:
    MCP_CAN _CAN;
    uint32_t pos_u32t;

    void readBuf(unsigned char *buf);
    void writeCmd(unsigned char *buf);
};

#endif
