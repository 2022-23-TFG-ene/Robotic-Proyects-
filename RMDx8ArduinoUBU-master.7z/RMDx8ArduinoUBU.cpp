// HAY QUE REVISAR 0X92
// DEBE SER MULTI-VUELTA Y POR TANTO CON 64 BITS.
// SI SE CAMBIA DE TIPO DE DATOS, HAY QUE MIRAR ESA RESTA DERIVADA DEL TIPO DE DATO 
// PARA QUE SEA CORRECTA (VER https://clickhouse.tech/docs/es/sql-reference/data-types/int-uint/).
// SU USO DEPENDE DEL ENCODER (DE 12bits A 18bits)
// -----------------------------
// HAY QUE DEFINIR LA FUNCI�N �MULTI MOTORS CONTROL COMMAND� CON ID 0X280
// ??????????????
// -----------------------------
// HAY QUE REVISAR LOS TIPOS DE DATOS  int16_t,  uint16_t, uint32_t, int32_t.
// -----------------------------
// -----------------------------


#include "Arduino.h"
#include "RMDx8ArduinoUBU.h"
#include <mcp_can.h>

// constructor
RMDx8ArduinoUBU::RMDx8ArduinoUBU(MCP_CAN &CAN, const uint16_t motor_addr) 
    :_CAN(CAN){
        MOTOR_ADDRESS = motor_addr;
    }

void RMDx8ArduinoUBU::canSetup() {
    while (CAN_OK != _CAN.begin(CAN_1000KBPS)) {
        Serial.println("CAN BUS Shield init fail");
        Serial.println("Init CAN BUS Shield again");
        delay(100);
    }
    Serial.println("CAN BUS Shield init ok!");
}

/** 
 * Single motor Command description
 * Write PID to RAM parameter command (one frame)
 * The host sends the command to write the PID parameters to the RAM. 
*/
void RMDx8ArduinoUBU::readPID() {
    cmd_buf[0] = 0x30;
    cmd_buf[1] = 0x00;
    cmd_buf[2] = 0x00;
    cmd_buf[3] = 0x00;
    cmd_buf[4] = 0x00;
    cmd_buf[5] = 0x00;
    cmd_buf[6] = 0x00;
    cmd_buf[7] = 0x00;
    
    // Send message
    writeCmd(cmd_buf);
    delay(100);
    readBuf(cmd_buf);

    // Receive message
    command = reply_buf[0];
    anglePidKp = reply_buf[2];
    anglePidKi = reply_buf[3];
    speedPidKp = reply_buf[4];
    speedPidKi = reply_buf[5];
    iqPidKp = reply_buf[6];
    iqPidKi = reply_buf[7];
}

/** 
 * Write PID to RAM parameter command (one frame)
 * The host sends the command to write the PID parameters to the RAM. Parameters are invalid when power
 * turned off.
*/
void RMDx8ArduinoUBU::writePID(uint8_t anglePidKp, uint8_t anglePidKi, uint8_t speedPidKp, uint8_t speedPidKi, uint8_t iqPidKp, uint8_t iqPidKi) {
    cmd_buf[0] = 0x31;
    cmd_buf[1] = 0x00;
    cmd_buf[2] = anglePidKp;
    cmd_buf[3] = anglePidKi;
    cmd_buf[4] = speedPidKp;
    cmd_buf[5] = speedPidKi;
    cmd_buf[6] = iqPidKp;
    cmd_buf[7] = iqPidKi;

    // Send message
    writeCmd(cmd_buf);
    readBuf(cmd_buf);
}

/** 
 * Write PID to ROM parameter command (one frame)
 * The host sends the command to write the PID parameters to the ROM. Parameter are still valid when power
 * turned off.
*/
void RMDx8ArduinoUBU::writePIDROM(uint8_t anglePidKp, uint8_t anglePidKi, uint8_t speedPidKp, uint8_t speedPidKi, uint8_t iqPidKp, uint8_t iqPidKi) {
    cmd_buf[0] = 0x32;
    cmd_buf[1] = 0x00;
    cmd_buf[2] = anglePidKp;
    cmd_buf[3] = anglePidKi;
    cmd_buf[4] = speedPidKp;
    cmd_buf[5] = speedPidKi;
    cmd_buf[6] = iqPidKp;
    cmd_buf[7] = iqPidKi;

    // Send message
    writeCmd(cmd_buf);
    readBuf(cmd_buf);
}

/** 
 * Read acceleration data command (one frame)
 * The host send the command to read motor acceleration data
 * The driver reply data include acceleration data, data type: int32_t; unit:1dps/s
*/
void RMDx8ArduinoUBU::readAccel() {
    cmd_buf[0] = 0x33;
    cmd_buf[1] = 0x00;
    cmd_buf[2] = 0x00;
    cmd_buf[3] = 0x00;
    cmd_buf[4] = 0x00;
    cmd_buf[5] = 0x00;
    cmd_buf[6] = 0x00;
    cmd_buf[7] = 0x00;

    // Send message
    writeCmd(cmd_buf);
    readBuf(cmd_buf);

    // Receive message
    command = reply_buf[0];
    Accel = ((uint32_t)reply_buf[7] << 24) + ((uint32_t)reply_buf[6] << 16) + ((uint32_t)reply_buf[5] << 8) + reply_buf[4];
}

/** 
 * Write acceleration data command (one frame)
 * The host sends the command to write the acceleration to the RAM, and the write parameters are invalid after
 * the power is turned off. Acceleration data Accel is int32_t type, unit 1dps/s
 * The motor responds to the host after receiving the command, the frame data is the same as the host sent
*/
void RMDx8ArduinoUBU::writeAccel(uint32_t Accel) {
    cmd_buf[0] = 0x34;
    cmd_buf[1] = 0x00;
    cmd_buf[2] = 0x00;
    cmd_buf[3] = 0x00;
    cmd_buf[4] = Accel & 0xFF;
    cmd_buf[5] = (Accel >> 8) & 0xFF;
    cmd_buf[6] = (Accel >> 16) & 0xFF;
    cmd_buf[7] = (Accel >> 24) & 0xFF;

    // Send message
    writeCmd(cmd_buf);
    readBuf(cmd_buf);
}

/** 
 * The host sends the command to read the current position of the encoder
 * The motor responds to the host after receiving the command, the frame data contains: 
 * Encoder current position (uint16_t type, 14bit encoder value range 0~16383), which is the encoder
 * original position minus the encoder zero offset value
 * Encoder original position (encoderRaw) (uint16_t type, 14bit encoder value range 0~16383)
 * EncoderOffset(uint16_t type, 14bit encoder value range 0~16383)
*/
void RMDx8ArduinoUBU::readEncoder() {
    cmd_buf[0] = 0x90;
    cmd_buf[1] = 0x00;
    cmd_buf[2] = 0x00;
    cmd_buf[3] = 0x00;
    cmd_buf[4] = 0x00;
    cmd_buf[5] = 0x00;
    cmd_buf[6] = 0x00;
    cmd_buf[7] = 0x00;

    // Send message
    writeCmd(cmd_buf);
    readBuf(cmd_buf);

    // Receive message
    command = reply_buf[0];
    encoder = ((uint16_t)reply_buf[3] << 8) + reply_buf[2];
    encoderRaw = ((uint16_t)reply_buf[5] << 8) + reply_buf[4];
    encoderOffset = ((uint16_t)reply_buf[7] << 8) + reply_buf[6];
}

/** 
 * The host sends the command to set encoder offset, written the encoder offset with uint16_t type, 14bit encoder value 
 * range (0, 16383)
 * The motor responds to the host after receiving the command, the frame data contains the following parameters: 
 * 	New encoderOffset (uint16_t type, 14bit encoder value range (0, 16383)) 
*/
void RMDx8ArduinoUBU::writeEncoderOffset(uint16_t encoderOffset) {
    cmd_buf[0] = 0x91;
    cmd_buf[1] = 0x00;
    cmd_buf[2] = 0x00;
    cmd_buf[3] = 0x00;
    cmd_buf[4] = 0x00;
    cmd_buf[5] = 0x00;
    cmd_buf[6] = encoderOffset & 0xFF;
    cmd_buf[7] = (encoderOffset >> 8) & 0xFF;

    // Send message
    writeCmd(cmd_buf);
    readBuf(cmd_buf);

    // Receive message
    command = reply_buf[0];
    encoderOffset = ((uint16_t)reply_buf[7] << 8) + reply_buf[6];
}

/** 
 * Write current position to ROM as motor zero position command(one frame)
 * This command needs to be powered on again to take effect.
 * This command will write the zero position to ROM. Multiple writes will affect the chip life. so not recommended to 
 * use it frequently.
 * The motor returns to the host after receiving the command, and the data is offset value.
*/
void RMDx8ArduinoUBU::writePositionROMMotorZero() {
    cmd_buf[0] = 0x19;
    cmd_buf[1] = 0x00;
    cmd_buf[2] = 0x00;
    cmd_buf[3] = 0x00;
    cmd_buf[4] = 0x00;
    cmd_buf[5] = 0x00;
    cmd_buf[6] = 0x00;
    cmd_buf[7] = 0x00;

    writeCmd(cmd_buf);
    readBuf(cmd_buf);

    // Receive message
    command = reply_buf[0];
    encoderOffset = ((uint16_t)reply_buf[7] << 8) + reply_buf[6];
}

/**  TO CHANGE � DEBE SER MULTI-VUELTA Y POR TANTO CON 64 BITS.
 * Read multi turns angle command (one frame)
 * The host sends command to read the multi-turn angle of the motor
 * The motor responds to the host after receiving the command, the frame data contains the following parameters: 
 * 	Motor angle, int64_t type data, positive value indicates clockwise cumulative angle, negative value indicates
 * 	counterclockwise cumulative angle, unit 0.01�/LSB.
*/
void RMDx8ArduinoUBU::readMotorAngle() {
    cmd_buf[0] = 0x92;
    cmd_buf[1] = 0x00;
    cmd_buf[2] = 0x00;
    cmd_buf[3] = 0x00;
    cmd_buf[4] = 0x00;
    cmd_buf[5] = 0x00;
    cmd_buf[6] = 0x00;
    cmd_buf[7] = 0x00;

    // Send message
    writeCmd(cmd_buf);
    readBuf(cmd_buf);

    // Receive message
    command = reply_buf[0];
    pos_u32t = ((uint32_t)reply_buf[4] << 24) + ((uint32_t)reply_buf[3] << 16) + ((uint32_t)reply_buf[2] << 8) + reply_buf[1];

    if (pos_u32t > 2147483648) {
        motorAngle = pos_u32t - 4294967296;
    }
    else {
        motorAngle = pos_u32t;
    }
}

/** 
 * Read single circle angle command (1 frame)
 * The host sends command to read the single circle angle of the motor.
 * The motor responds to the host after receiving the command, the frame data contains the following parameters: 
 * 	CircleAngle, uint16_t type data, starting from the encoder zero point, increased by clockwise rotation, and 
 * 	returning to zero when it reaches zero again, the unit is 0.01�/LSB.
*/
void RMDx8ArduinoUBU::readSingleCircleAngle() {
    cmd_buf[0] = 0x94;
    cmd_buf[1] = 0x00;
    cmd_buf[2] = 0x00;
    cmd_buf[3] = 0x00;
    cmd_buf[4] = 0x00;
    cmd_buf[5] = 0x00;
    cmd_buf[6] = 0x00;
    cmd_buf[7] = 0x00;

    writeCmd(cmd_buf);
    readBuf(cmd_buf);

    command = reply_buf[0];
    circleAngle = ((uint16_t)reply_buf[7] << 8) + reply_buf[6];
}

/** 
 * Read motor status 1 and error flag commands (one frame)
 * This command reads the motor's error status and voltage, temperature and other information.
 * The motor responds to the host after receiving the command, the frame data contains the following parameters:
 * 	Motor temperature (int8_t type,unit 1?/LSB) 
 * 	Voltage (uint16_t type, unit 0.1V/LSB) 
 * 	Error State (uint8_t type, Each bit represents a different motor state) 	
 * The control value voltage limits the maximum voltage at which the motor rotates, uint16_t type,  corresponding
 * to the actual voltage of 0.1 V/LSB.
 * The control value error_state determine the error produced.Each bit represents a different motor state.
*/
void RMDx8ArduinoUBU::readStatus1() {
    cmd_buf[0] = 0x9A;
    cmd_buf[1] = 0x00;
    cmd_buf[2] = 0x00;
    cmd_buf[3] = 0x00;
    cmd_buf[4] = 0x00;
    cmd_buf[5] = 0x00;
    cmd_buf[6] = 0x00;
    cmd_buf[7] = 0x00;

    // Send message
    writeCmd(cmd_buf);
    readBuf(cmd_buf);

    // Receive message
    command = reply_buf[0];
    temperature = reply_buf[1];
    voltage = ((int16_t)reply_buf[4] << 8) + reply_buf[3];
    error_state = reply_buf[7];

    if (error_state == 1) Serial.println("*** Low voltage protection"); // bit 0
    if (error_state == 8) Serial.println("*** Over temperature protection"); // bit 4
}

/** 
 * Clear motor error flag command (one frame)
 * This command clears the error status of the current motor.
 * The motor responds to the host after receiving the command, the frame data contains the following parameters:
 * 	Motor temperature (int8_t type,unit 1?/LSB) 
 * 	Voltage (uint16_t type, unit 0.1V/LSB) 
 * 	Error State (uint8_t type, Each bit represents a different motor state) 	
 * The control value voltage limits the maximum voltage at which the motor rotates, uint16_t type,  corresponding
 * to the actual voltage of 0.1 V/LSB.
 * The control value error_state determine the error produced.Each bit represents a different motor state.
*/
void RMDx8ArduinoUBU::clearErrorFlag() {
    cmd_buf[0] = 0x9B;
    cmd_buf[1] = 0x00;
    cmd_buf[2] = 0x00;
    cmd_buf[3] = 0x00;
    cmd_buf[4] = 0x00;
    cmd_buf[5] = 0x00;
    cmd_buf[6] = 0x00;
    cmd_buf[7] = 0x00;

    // Send message
    writeCmd(cmd_buf);
    readBuf(cmd_buf);

    // Receive message
    command = reply_buf[0];
    temperature = reply_buf[1];
    voltage = ((int16_t)reply_buf[4] << 8) + reply_buf[3];
    error_state = reply_buf[7];

    if (error_state == 1) Serial.println("*** Low voltage protection"); // bit 0
    if (error_state == 8) Serial.print("*** Over temperature protection"); // bit 4
}

/** 
 * Read motor status 2 (one frame)
 * This command reads motor temperature, voltage, speed, encoder position
 * 	Motor temperature(int8_t type,unit 1?/LSB)
 * 	Motor torque current (Iq) is int16_t type, the value range: (-2048, 2048), corresponding to the actual torque 
 * 	current range (-33A, 33A) (the bus current and the actual torque of motor vary with different motors)
 * 	Motor speed is int16_t type, which corresponds to the actual speed of 1dps/LSB.
 * 	Encoder position value is uint16_t type, 14bit encoder value range (0, 16383)
*/
void RMDx8ArduinoUBU::readStatus2() {
    cmd_buf[0] = 0x9C;
    cmd_buf[1] = 0x00;
    cmd_buf[2] = 0x00;
    cmd_buf[3] = 0x00;
    cmd_buf[4] = 0x00;
    cmd_buf[5] = 0x00;
    cmd_buf[6] = 0x00;
    cmd_buf[7] = 0x00;

    // Send message
    writeCmd(cmd_buf);
    readBuf(cmd_buf);

    // Receive message
    command = reply_buf[0];
    temperature = reply_buf[1];
    iq = ((int16_t)reply_buf[3] << 8) + reply_buf[2];
    speed = ((int16_t)reply_buf[5] << 8) + reply_buf[4];
    encoder = ((uint16_t)reply_buf[7] << 8) + reply_buf[6];
}

/** 
 * Read motor status 3 (one frame)
 * This command reads the phase current status data of the motor.
 * The motor returns to the host after receiving the command. The frame data contains three-phase current data, the
 * data type is int16_t type, corresponding to the actual phase current is 1A/64LSB.
*/
void RMDx8ArduinoUBU::readStatus3() {
    cmd_buf[0] = 0x9D;
    cmd_buf[1] = 0x00;
    cmd_buf[2] = 0x00;
    cmd_buf[3] = 0x00;
    cmd_buf[4] = 0x00;
    cmd_buf[5] = 0x00;
    cmd_buf[6] = 0x00;
    cmd_buf[7] = 0x00;

    // Send message
    writeCmd(cmd_buf);
    readBuf(cmd_buf);

    // Receive message
    command = reply_buf[0];
    iA = ((int16_t)reply_buf[3] << 8) + reply_buf[2];
    iB = ((int16_t)reply_buf[5] << 8) + reply_buf[4];
    iC = ((int16_t)reply_buf[7] << 8) + reply_buf[6];
}

/** 
 * Motor off command(one frame)
 * Turn off motor, while clearing the motor operating status and previously received control commands
 * The motor responds to the host after receiving the command, the frame data is the same as the host sent
*/
void RMDx8ArduinoUBU::clearState() {
    cmd_buf[0] = 0x80;
    cmd_buf[1] = 0x00;
    cmd_buf[2] = 0x00;
    cmd_buf[3] = 0x00;
    cmd_buf[4] = 0x00;
    cmd_buf[5] = 0x00;
    cmd_buf[6] = 0x00;
    cmd_buf[7] = 0x00;

    writeCmd(cmd_buf);
    readBuf(cmd_buf);
}

/** 
 * Motor stop command (one frame)
 * Stop motor, but do not clear the motor operating state and previously received control commands
 * The motor responds to the host after receiving the command, the frame data is the same as the host sent
*/
void RMDx8ArduinoUBU::stopMotor() {
    cmd_buf[0] = 0x81;
    cmd_buf[1] = 0x00;
    cmd_buf[2] = 0x00;
    cmd_buf[3] = 0x00;
    cmd_buf[4] = 0x00;
    cmd_buf[5] = 0x00;
    cmd_buf[6] = 0x00;
    cmd_buf[7] = 0x00;

    writeCmd(cmd_buf);
    readBuf(cmd_buf);
}

/** 
 * Motor running command (one frame)
 * Resume motor operation from motor stop command (Recovery control mode before stop motor)
 * The motor responds to the host after receiving the command, the frame data is the same as the host sent
*/
void RMDx8ArduinoUBU::resumeStopMotor() {
    cmd_buf[0] = 0x88;
    cmd_buf[1] = 0x00;
    cmd_buf[2] = 0x00;
    cmd_buf[3] = 0x00;
    cmd_buf[4] = 0x00;
    cmd_buf[5] = 0x00;
    cmd_buf[6] = 0x00;
    cmd_buf[7] = 0x00;

    writeCmd(cmd_buf);
    readBuf(cmd_buf);
}

/**
 * Torque current control command (one frame)
 * The host sends the command to control torque current output of the motor. Iq Control is int16_t type, the value range: 
 * (-2000, 2000), corresponding to the actual torque current range (-32A, 32A).
 * The bus current and the actual torque of motor vary with different motors.
 * Iq Control in this command is not limited by the Max Torque Current value in the host computer.
 * The motor responds to the host after receiving the command, the frame data contains the following parameters:
 * 	Motor temperature (int8_t type, unit 1?/LSB)
 * 	Motor torque current (Iq) (int16_t type, Range: (-2048, 2048), real torque current range: (-33A, 33A)
 * 	Motor speed (int16_t type, 1dps/LSB)
 * 	Encoder position value (uint16_t type, 14bit encoder value range (0, 16383)
 */
void RMDx8ArduinoUBU::writeCurrent(int16_t iqControl) {
    cmd_buf[0] = 0xA1;
    cmd_buf[1] = 0x00;
    cmd_buf[2] = 0x00;
    cmd_buf[3] = 0x00;
    cmd_buf[4] = iqControl & 0xFF;
    cmd_buf[5] = (iqControl) >> 8 & 0xFF;
    cmd_buf[6] = 0x00;
    cmd_buf[7] = 0x00;

    // Send message
    writeCmd(cmd_buf);
    readBuf(cmd_buf);

    // Receive message
    command = reply_buf[0];
    temperature = reply_buf[1];
    iq = ((int16_t)reply_buf[3] << 8) + reply_buf[2];
    speed = ((int16_t)reply_buf[5] << 8) + reply_buf[4];
    encoder = ((uint16_t)reply_buf[7] << 8) + reply_buf[6];
}

/**
 * Speed control command (one frame)
 * The host sends this command to control the speed of the motor. Speed Control is int32_t type, which corresponds to 
 * the actual speed of 0.01dps/LSB.
 * The maximum torque current under this command is limited by the Max Torque Current value in the host computer.
 * In this control mode, the maximum acceleration of the motor is limited by the Max Acceleration value in the host 
 * computer.
 * The motor responds to the host after receiving the command, the frame data contains the following parameters:
 * 	Motor temperature (int8_t type, unit 1?/LSB)
 * 	Motor torque current (Iq) (int16_t type, Range: (-2048, 2048), real torque current range: (-33A, 33A)
 * 	Motor speed (int16_t type, 1dps/LSB)
 * 	Encoder position value (uint16_t type, 14bit encoder value range (0, 16383)
 */
void RMDx8ArduinoUBU::writeSpeed(int32_t speedControl) {
    cmd_buf[0] = 0xA2;
    cmd_buf[1] = 0x00;
    cmd_buf[2] = 0x00;
    cmd_buf[3] = 0x00;
    cmd_buf[4] = speedControl & 0xFF; 
    cmd_buf[5] = (speedControl >> 8) & 0xFF;
    cmd_buf[6] = (speedControl >> 16) & 0xFF;
    cmd_buf[7] = (speedControl >> 24) & 0xFF;

    // Send message
    writeCmd(cmd_buf);
    readBuf(cmd_buf);

    // Receive message
    command = reply_buf[0];
    temperature = reply_buf[1];
    iq = ((int16_t)reply_buf[3] << 8) + reply_buf[2];
    speed = ((int16_t)reply_buf[5] << 8) + reply_buf[4];
    encoder = ((uint16_t)reply_buf[7] << 8) + reply_buf[6];
}

/**
 * Position control command 1 (one frame)
 * The host sends this command to control the position of the motor (multi-turn angle).Angle Control is int32_t type, 
 * and the actual position is 0.01degree/LSB, 36000 represents 360�. The motor rotation direction is determined by the 
 * difference between the target position and the current position.
 * Angle Control under this command is limited by the Max Angle value in the host computer.
 * The maximum speed under this command is limited by the Max Speed value in the host computer.
 * In this control mode, the maximum acceleration of the motor is limited by the Max Acceleration value in the host 
 * computer.
 * In this control mode, the maximum torque current of the motor is limited by the Max Torque Current value in the 
 * host computer.
* The motor responds to the host after receiving the command, the frame data contains the following parameters:
 * 	Motor temperature (int8_t type, unit 1?/LSB)
 * 	Motor torque current (Iq) (int16_t type, Range: (-2048, 2048), real torque current range: (-33A, 33A)
 * 	Motor speed (int16_t type, 1dps/LSB)
 * 	Encoder position value (uint16_t type, 14bit encoder value range (0, 16383)
 */
void RMDx8ArduinoUBU::writePosition3(int32_t angleControlMT) {
    cmd_buf[0] = 0xA3;
    cmd_buf[1] = 0x00;
    cmd_buf[2] = 0x00;
    cmd_buf[3] = 0x00;
    cmd_buf[4] = angleControlMT & 0xFF; 		// 32 bits
    cmd_buf[5] = (angleControlMT >> 8) & 0xFF;
    cmd_buf[6] = (angleControlMT >> 16) & 0xFF;
    cmd_buf[7] = (angleControlMT >> 24) & 0xFF;

    // Send message
    writeCmd(cmd_buf);
    readBuf(cmd_buf);

    // Receive message
    command = reply_buf[0];
    temperature = reply_buf[1];
    iq = ((int16_t)reply_buf[3] << 8) + reply_buf[2];
    speed = ((int16_t)reply_buf[5] << 8) + reply_buf[4];
    encoder = ((uint16_t)reply_buf[7] << 8) + reply_buf[6];
    //encoder = ((uint8_t)reply_buf[7]);
}

/**
 * # Position control command 2, multi turns (one frame)
 * The host sends this command to control the position of the motor (multi-turn angle). Angle Control is int32_t type, 
 * and the actual position is 0.01degree/LSB, 36000 represents 360�. The motor rotation direction is determined by the 
 * difference between the target position and the current position.
 * The control value maxSpeed limits the maximum speed at which the motor rotates, uint16_t type, corresponding to 
 * the actual speed of 1dps/LSB.
 * Angle Control under this command is limited by the Max Angle value in the host computer.
 * In this control mode, the maximum acceleration of the motor is limited by the Max Acceleration value in the host 
 * computer.
 * In this control mode, the maximum torque current of the motor is limited by the Max Torque Current value in the 
 * host computer.
* The motor responds to the host after receiving the command, the frame data contains the following parameters:
 * 	Motor temperature (int8_t type, unit 1?/LSB)
 * 	Motor torque current (Iq) (int16_t type, Range: (-2048, 2048), real torque current range: (-33A, 33A)
 * 	Motor speed (int16_t type, 1dps/LSB)
 * 	Encoder position value (uint16_t type, 14bit encoder value range (0, 16383)
 */
void RMDx8ArduinoUBU::writePosition4(int32_t angleControlMT, uint16_t maxSpeed) {
    cmd_buf[0] = 0xA4;
    cmd_buf[1] = 0x00;
    cmd_buf[2] = maxSpeed & 0xFF;
    cmd_buf[3] = (maxSpeed >> 8) & 0xFF;
    cmd_buf[4] = angleControlMT & 0xFF; 		// 32 bits
    cmd_buf[5] = (angleControlMT >> 8) & 0xFF;
    cmd_buf[6] = (angleControlMT >> 16) & 0xFF;
    cmd_buf[7] = (angleControlMT >> 24) & 0xFF;

    // Send message
    writeCmd(cmd_buf);
    readBuf(cmd_buf);

    // Receive message
    command = reply_buf[0];
    temperature = reply_buf[1];
    iq = ((int16_t)reply_buf[3] << 8) + reply_buf[2];
    speed = ((int16_t)reply_buf[5] << 8) + reply_buf[4];
    encoder = ((uint16_t)reply_buf[7] << 8) + reply_buf[6];
}

/**
 * Position control command 3, single turn (one frame)
 * The host sends this command to control the position of the motor (single-turn angle). Angle Control is uint16_t type, 
 * the value range is (0, 35999), and the actual position is 0.01 degree/LSB, the actual angle range is (0�, 359.99�).
 * The control value spin_direction sets the direction in which the motor rotates, which is uint8_t type, 0x00 for 
 * clockwise (CW) and 0x01 for counterclockwise (CCW).
 * The maximum speed under this command is limited by the Max Speed value in the host computer.
 * In this control mode, the maximum acceleration of the motor is limited by the Max Acceleration value in the host 
 * computer.
 * In this control mode, the maximum torque current of the motor is limited by the Max Torque Current value in the 
 * host computer.
* The motor responds to the host after receiving the command, the frame data contains the following parameters:
 * 	Motor temperature (int8_t type, unit 1?/LSB)
 * 	Motor torque current (Iq) (int16_t type, Range: (-2048, 2048), real torque current range: (-33A, 33A)
 * 	Motor speed (int16_t type, 1dps/LSB)
 * 	Encoder position value (uint16_t type, 14bit encoder value range (0, 16383)
 */
void RMDx8ArduinoUBU::writePosition5(uint16_t angleControlST, uint8_t spinDirection) {
    cmd_buf[0] = 0xA5;
    cmd_buf[1] = spinDirection;
    cmd_buf[2] = 0x00;
    cmd_buf[3] = 0x00;
    cmd_buf[4] = angleControlST & 0xFF; 		// 16 bits
    cmd_buf[5] = (angleControlST >> 8) & 0xFF;
    cmd_buf[6] = 0x00;
    cmd_buf[7] = 0x00;

    // Send message
    writeCmd(cmd_buf);
    readBuf(cmd_buf);

    // Receive message
    command = reply_buf[0];
    temperature = reply_buf[1];
    iq = ((int16_t)reply_buf[3] << 8) + reply_buf[2];
    speed = ((int16_t)reply_buf[5] << 8) + reply_buf[4];
    encoder = ((uint16_t)reply_buf[7] << 8) + reply_buf[6];
}

/** 
 * # Position control command 4, single turn (one frame)
 * The host sends this command to control the position of the motor (single-turn angle)
 * Angle Control is uint16_t type, the value range is (0, 35999), and the actual position is 0.01 degree/LSB, the actual 
 * angle range is (0�, 359.99�).
 * The control value spin_direction sets the direction in which the motor rotates, which is uint8_t type, 0x00 for 
 * clockwise (CW) and 0x01 for counterclockwise (CCW).
 * Max Speed limits the maximum speed of motor rotation, which is uint16_t type, corresponding to the
 * actual speed of 1dps/LSB.
 * In this control mode, the maximum acceleration of the motor is limited by the Max Acceleration value in the host 
 * computer.
 * In this control mode, the maximum torque current of the motor is limited by the Max Torque Current value in the 
 * host computer.
* The motor responds to the host after receiving the command, the frame data contains the following parameters:
 * 	Motor temperature (int8_t type, unit 1?/LSB)
 * 	Motor torque current (Iq) (int16_t type, Range: (-2048, 2048), real torque current range: (-33A, 33A)
 * 	Motor speed (int16_t type, 1dps/LSB)
 * 	Encoder position value (uint16_t type, 14bit encoder value range (0, 16383)
 */
void RMDx8ArduinoUBU::writePosition6(uint16_t angleControlST, uint16_t maxSpeed, uint8_t spinDirection) {
    cmd_buf[0] = 0xA6;
    cmd_buf[1] = spinDirection;
    cmd_buf[2] = maxSpeed & 0xFF;
    cmd_buf[3] = (maxSpeed >> 8) & 0xFF;
    cmd_buf[4] = angleControlST & 0xFF; 		// 16 bits
    cmd_buf[5] = (angleControlST >> 8) & 0xFF;
    cmd_buf[6] = 0x00;
    cmd_buf[7] = 0x00;

    // Send message
    writeCmd(cmd_buf);
    readBuf(cmd_buf);

    // Receive message
    command = reply_buf[0];
    temperature = reply_buf[1];
    iq = ((int16_t)reply_buf[3] << 8) + reply_buf[2];
    speed = ((int16_t)reply_buf[5] << 8) + reply_buf[4];
    encoder = ((uint16_t)reply_buf[7] << 8) + reply_buf[6];
}

// General function
void RMDx8ArduinoUBU::serialWriteTerminator() {
    Serial.write(13);
    Serial.write(10);
}

// Private
void RMDx8ArduinoUBU::readBuf(unsigned char *buf) {
    delayMicroseconds(600);    // 1000us
    if (CAN_MSGAVAIL == _CAN.checkReceive()) {
        _CAN.readMsgBuf(&len, tmp_buf);
        if (tmp_buf[0] == buf[0]) {
            reply_buf[0] = tmp_buf[0];
            reply_buf[1] = tmp_buf[1];
            reply_buf[2] = tmp_buf[2];
            reply_buf[3] = tmp_buf[3];
            reply_buf[4] = tmp_buf[4];
            reply_buf[5] = tmp_buf[5];
            reply_buf[6] = tmp_buf[6];
            reply_buf[7] = tmp_buf[7];
        }
    }
}

void RMDx8ArduinoUBU::writeCmd(unsigned char *buf) {
    // CAN通信�?��?る
    unsigned char sendState = _CAN.sendMsgBuf(MOTOR_ADDRESS, 0, 8, buf);
    if (sendState != CAN_OK) { //  //
        Serial.println("Error Sending Message (RMDx8ArduinoUBU.h)...");
        Serial.print("sendState= "); Serial.println(sendState);
        Serial.print(" - CAN_FAILTX= ");Serial.print(CAN_FAILTX);
        Serial.print(" - CAN_OK= ");Serial.println(CAN_OK);
   }
}
